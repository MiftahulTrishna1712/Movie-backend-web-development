const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');

dotenv.config();

const app = express();
app.use(express.json());
app.use(cookieParser());

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);

app.get('/', (req, res) => {
    res.cookie("name", "Trishna");
    res.send("Backend is running smoothly.");
});

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected successfully"))
  .catch((error) => console.error("MongoDB connection failed:", error.message));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
