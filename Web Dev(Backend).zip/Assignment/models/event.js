const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
    name: {type:string,required:true},
    userid: {type:string,required:true,unique:true},
    id: Number
});
export default mongoose.model("User", userSchema )